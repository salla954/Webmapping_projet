/* =========================================================================
   SITS SÉNÉGAL — Module Régions & Départements
   Rôle dans le projet : consommation de l'API REST (AJAX/Fetch) +
   affichage/interaction des couches Régions et Départements sur Leaflet.

   -------------------------------------------------------------------------
   CONTRAT D'API attendu (à transmettre à la personne qui fait l'API Python)
   -------------------------------------------------------------------------
   GET {API_BASE_URL}/regions
     -> FeatureCollection GeoJSON des régions

   GET {API_BASE_URL}/departements
     -> FeatureCollection GeoJSON de TOUS les départements
   GET {API_BASE_URL}/departements?region=<code_ou_nom_region>
     -> FeatureCollection GeoJSON des départements d'une région donnée

   GET {API_BASE_URL}/regions/search?q=<texte>
   GET {API_BASE_URL}/departements/search?q=<texte>
     -> recherche texte (bonus, pas bloquant pour commencer)

   GET {API_BASE_URL}/infrastructures?type=<ecoles|sante|forage|marche|sport|autres>
     -> FeatureCollection GeoJSON des points d'infrastructure du type demandé
        (mêmes clés de propriétés que les fichiers locaux : nom, type_label,
        region.nom, departement.nom, commune.nom, quartier_village, milieu)

   Tant que l'API n'existe pas, ce fichier lit directement les fichiers
   GeoJSON dans data/. Il suffit de passer CONFIG.USE_API à true et de
   renseigner CONFIG.API_BASE_URL le jour où l'API est prête : aucune autre
   ligne de ce fichier n'a besoin de changer.
   ========================================================================= */

const CONFIG = {
  USE_API: false, // API Flask disponible dans api/ — voir api/README ou le README principal pour la lancer
  API_BASE_URL: "http://127.0.0.1:5000/api",

  // Chemins locaux utilisés tant que USE_API = false.
  // Adapte les noms de fichiers à ceux que tu as réellement dans data/.
  LOCAL_REGIONS_PATH: "data/regions.geojson",
  LOCAL_DEPARTEMENTS_PATH: "data/departements.geojson",

  // Un fichier local par type d'infrastructure. Le jour où l'API est prête,
  // ces chemins ne servent plus : infraURL() bascule sur /infrastructures?type=...
  LOCAL_INFRA_PATHS: {
    ecoles: "data/lycee.geojson",
    sante: "data/centre_sante.geojson",
    forage: "data/forage.geojson",
    marche: "data/marche.geojson",
    sport: "data/loisirs.geojson",
    autres: "data/parking.geojson",
  },
};

/* -------------------------------------------------------------------------
   Couche Infrastructures — 6 types imposés par le cahier des charges.
   Remarque importante sur les données disponibles à ce jour :
     - "ecoles" ne contient que les lycées publics (data/lycee.geojson) :
       aucun fichier écoles primaires/collèges n'a été fourni.
     - "sport" n'a pas de fichier dédié : le jeu de données "loisirs"
       est filtré (piscines, aires de jeux, gymnases) via `filter` ci-dessous.
     - "autres" s'appuie sur data/parking.geojson (seule couche d'infrastructure
       publique restante et non déjà utilisée ailleurs dans l'appli).
   Si de meilleurs fichiers sont fournis plus tard, il suffit de changer le
   chemin dans CONFIG.LOCAL_INFRA_PATHS et/ou de retirer le `filter` : aucune
   autre ligne du fichier n'a besoin de changer.
   ------------------------------------------------------------------------- */
function isSportFeature(feature) {
  const nom = String((feature.properties || {}).nom || "").toUpperCase();
  return /PISCINE|AIRE DE JEUX|GYMNASE/.test(nom);
}

const INFRA_TYPES = {
  ecoles: {
    label: "Établissements scolaires (lycées)",
    color: "#3b82f6",
  },
  sante: {
    label: "Centres de santé",
    color: "#ef4444",
  },
  forage: {
    label: "Forages",
    color: "#0ea5e9",
  },
  marche: {
    label: "Marchés",
    color: "#f59e0b",
  },
  sport: {
    label: "Équipements sportifs",
    color: "#22c55e",
    filter: isSportFeature,
    note: "Le jeu de données fourni n'a pas de couche sportive dédiée : seules les infrastructures de loisir identifiées comme sportives (piscines, aires de jeux, gymnases) sont affichées ici.",
  },
  autres: {
    label: "Autres infrastructures publiques (parkings)",
    color: "#a855f7",
  },
};

// Symboles SVG (24x24) associés à chaque type — dessinés simplement pour
// rester lisibles à petite taille dans une pastille de 28px.
function infraGlyph(key, color) {
  switch (key) {
    case "ecoles":
      return '<path d="M12 3 2 8l10 5 10-5-10-5Z" fill="#fff"/>'
        + '<path d="M6 11.3V16c0 1.8 2.8 3.2 6 3.2s6-1.4 6-3.2v-4.7l-6 3-6-3Z" fill="#fff"/>';
    case "sante":
      return '<path d="M10 3h4v6h6v4h-6v8h-4v-8H4V9h6V3Z" fill="#fff"/>';
    case "forage":
      return '<path d="M12 2C12 2 5 11.2 5 15.6 5 19.7 8.1 22 12 22s7-2.3 7-6.4C19 11.2 12 2 12 2Z" fill="#fff"/>';
    case "marche":
      return '<path d="M9 8V7a3 3 0 0 1 6 0v1" fill="none" stroke="#fff" stroke-width="1.6"/>'
        + '<path d="M6.5 8h11l-1.3 10.2a2 2 0 0 1-2 1.8H9.8a2 2 0 0 1-2-1.8L6.5 8Z" fill="#fff"/>';
    case "sport":
      return '<circle cx="12" cy="12" r="8" fill="#fff"/>'
        + `<path d="M12 6.2v11.6M6.2 12h11.6M8.2 8.2l7.6 7.6M15.8 8.2l-7.6 7.6" stroke="${color}" stroke-width="1" fill="none" opacity=".5"/>`;
    case "autres":
      return '<text x="12" y="17" font-size="13" font-weight="700" text-anchor="middle" fill="#fff" font-family="Arial, sans-serif">P</text>';
    default:
      return '<circle cx="12" cy="12" r="6" fill="#fff"/>';
  }
}

const infraIconCache = {};
function getInfraIcon(key) {
  if (!infraIconCache[key]) {
    const type = INFRA_TYPES[key];
    const html = `<div class="infra-marker" style="background:${type.color}">`
      + `<svg viewBox="0 0 24 24" width="16" height="16">${infraGlyph(key, type.color)}</svg></div>`;
    infraIconCache[key] = L.divIcon({
      html,
      className: "infra-divicon",
      iconSize: [28, 28],
      iconAnchor: [14, 14],
      popupAnchor: [0, -14],
    });
  }
  return infraIconCache[key];
}

function makeClusterIconFn(color) {
  return function (cluster) {
    const count = cluster.getChildCount();
    const size = count < 10 ? 32 : count < 100 ? 38 : 46;
    return L.divIcon({
      html: `<div class="infra-cluster" style="background:${color}">${count}</div>`,
      className: "infra-divicon",
      iconSize: [size, size],
    });
  };
}

// Noms de propriétés confirmés dans les fichiers fournis (regions.geojson,
// departements.geojson) : nom, code, region_code. Les listes ci-dessous
// gardent quelques alias au cas où d'autres fichiers de l'équipe (SHP
// convertis, etc.) utiliseraient des noms légèrement différents.
const REGION_NAME_KEYS = ["nom", "NOM_REG", "name"];
const REGION_CODE_KEYS = ["code", "CODE_REG"];
const DEPT_NAME_KEYS   = ["nom", "NOM_DEPT", "name"];
const DEPT_CODE_KEYS   = ["code", "CODE_DEPT"];
const DEPT_REGION_LINK_KEYS = ["region_code", "region_nom"]; // champ qui relie un département à sa région

// Normalise un nom pour des comparaisons insensibles à la casse et aux
// accents (utilisé par la recherche multicritère, notamment pour relier
// une région sélectionnée aux propriétés "region.nom" des infrastructures,
// dont le référentiel de codes diffère de celui de regions.geojson).
function normalizeName(value) {
  return String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toUpperCase()
    .replace(/-/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function getProp(feature, keys, fallback = "—") {
  const props = feature.properties || {};
  for (const k of keys) {
    if (props[k] !== undefined && props[k] !== null && props[k] !== "") return props[k];
  }
  return fallback;
}

// Lecture d'une propriété imbriquée façon "region.nom" — utilisé par la
// couche Infrastructures dont les fichiers stockent région/département/
// commune sous forme d'objets ({ nom, code }) plutôt qu'à plat.
function getNestedProp(feature, path, fallback = "—") {
  const parts = path.split(".");
  let value = feature.properties;
  for (const part of parts) {
    if (value === undefined || value === null) return fallback;
    value = value[part];
  }
  return value === undefined || value === null || value === "" ? fallback : value;
}

// ---------------------------------------------------------------------
// État global du module
// ---------------------------------------------------------------------
const state = {
  map: null,
  layersControl: null,          // instance du contrôle de couches Leaflet (haut droite)
  regionsLayer: null,
  departementsLayer: null,
  departementsVisible: true,    // persiste l'état de la case "Départements" à travers les filtres
  allDepartementsGeoJSON: null, // gardé en mémoire pour filtrer côté client
  activeLayer: null,            // layer Leaflet actuellement mis en évidence
  infraGroups: {},              // clé de type -> L.markerClusterGroup (créés vides dès le départ)
  infraLoaded: {},              // clé de type -> déjà chargé/rempli ou non
};

// ---------------------------------------------------------------------
// 1. Initialisation de la carte
// ---------------------------------------------------------------------
function initMap() {
  state.map = L.map("map", {
    zoomControl: true,     // boutons + / - -> zoom avant / zoom arrière
    dragging: true,        // déplacement de la carte à la souris/au doigt
    scrollWheelZoom: true, // zoom à la molette
    doubleClickZoom: true, // zoom au double-clic
    touchZoom: true,       // pincer-zoomer sur écran tactile
    keyboard: true,        // déplacement au clavier (flèches) une fois la carte focus
  }).setView([14.4974, -14.4524], 7); // centre approximatif du Sénégal

  L.control.scale({ position: "bottomleft", metric: true, imperial: false }).addTo(state.map);

  const osm = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "&copy; OpenStreetMap",
    maxZoom: 19,
  }).addTo(state.map);

  const satellite = L.tileLayer(
    "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    { attribution: "Tiles &copy; Esri", maxZoom: 19 }
  );

  // Fonds de carte supplémentaires : deux variantes CARTO (claire/sombre,
  // utiles pour faire ressortir les couches de couleur par-dessus) et un
  // fond relief, en plus de l'OSM clair et du satellite déjà présents.
  const cartoPositron = L.tileLayer(
    "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png",
    { attribution: "&copy; OpenStreetMap contributors &copy; CARTO", maxZoom: 20, subdomains: "abcd" }
  );
  const cartoDark = L.tileLayer(
    "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",
    { attribution: "&copy; OpenStreetMap contributors &copy; CARTO", maxZoom: 20, subdomains: "abcd" }
  );
  const openTopo = L.tileLayer(
    "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png",
    { attribution: "&copy; OpenStreetMap contributors, SRTM | &copy; OpenTopoMap (CC-BY-SA)", maxZoom: 17 }
  );

  // Contrôle de couches Leaflet natif : fonds de carte (radio) + Régions/
  // Départements (cases à cocher). Réduit par défaut (juste une icône,
  // se déplie au survol/clic) et positionné en bas à droite pour rester
  // discret. Les 6 couches d'infrastructures ne sont PAS listées ici
  // (volontairement) : elles se gèrent depuis le panneau latéral
  // "Couches", pour éviter d'avoir la même liste de 8 entrées à deux
  // endroits — voir initInfraGroups().
  state.layersControl = L.control.layers(
    {
      "Fond clair (OSM)": osm,
      "Fond clair (CARTO Positron)": cartoPositron,
      "Fond sombre (CARTO Dark Matter)": cartoDark,
      "Relief (OpenTopoMap)": openTopo,
      "Fond satellite (Esri)": satellite,
    },
    {},
    { collapsed: true, position: "bottomright" }
  ).addTo(state.map);

  initAdvancedControls();

  // Point de synchronisation unique entre le contrôle Leaflet (en haut à
  // droite) et le panneau "Couches" du panneau latéral : quel que soit
  // l'endroit où une couche est activée/désactivée (clic sur le contrôle
  // natif, sur une case à cocher du panneau, ou reset), 'layeradd' /
  // 'layerremove' sont déclenchés par Leaflet dans tous les cas, donc les
  // deux UI restent toujours d'accord sur l'état réel de la carte.
  state.map.on("layeradd layerremove", onMapLayerToggle);
}

function onMapLayerToggle(e) {
  const key = e.layer && e.layer._legendKey;
  if (!key) return; // couche non gérée par le panneau (fond de carte, etc.)

  const visible = e.type === "layeradd";
  const checkbox = document.getElementById(`layer-check-${key}`);
  if (checkbox) checkbox.checked = visible;

  if (key.startsWith("infra:")) {
    const infraKey = key.slice("infra:".length);
    if (visible && !state.infraLoaded[infraKey]) {
      loadInfraData(infraKey);
    }
  } else if (key === "departements") {
    state.departementsVisible = visible;
  }
}

// ---------------------------------------------------------------------
// 2. Couche AJAX générique — c'est ici que se fait la "consommation d'API"
// ---------------------------------------------------------------------
async function fetchGeoJSON(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Échec du chargement (${response.status}) : ${url}`);
  }
  const data = await response.json();
  if (!data || !Array.isArray(data.features)) {
    throw new Error(`Réponse invalide, FeatureCollection attendue : ${url}`);
  }
  return data;
}

function regionsURL() {
  return CONFIG.USE_API ? `${CONFIG.API_BASE_URL}/regions` : CONFIG.LOCAL_REGIONS_PATH;
}

function departementsURL(regionKey) {
  if (!CONFIG.USE_API) return CONFIG.LOCAL_DEPARTEMENTS_PATH; // filtrage fait côté client
  const base = `${CONFIG.API_BASE_URL}/departements`;
  return regionKey ? `${base}?region=${encodeURIComponent(regionKey)}` : base;
}

// ---------------------------------------------------------------------
// 3. Couche Régions
// ---------------------------------------------------------------------
async function loadRegions() {
  setStatus("Chargement des régions…");
  const geojson = await fetchGeoJSON(regionsURL());

  state.regionsLayer = L.geoJSON(geojson, {
    style: () => ({
      color: "#0d9488",
      weight: 2,
      fillColor: "#14b8a6",
      fillOpacity: 0.12,
    }),
    onEachFeature: (feature, layer) => {
      const name = getProp(feature, REGION_NAME_KEYS);
      const code = getProp(feature, REGION_CODE_KEYS);

      layer.bindPopup(buildPopupHTML(name, [
        ["Code", code],
        ["Type", "Région"],
      ]));

      layer.on("click", () => {
        highlightLayer(layer);
        zoomToLayer(layer);
        showInfoPanel(name, [
          ["Code", code],
          ["Type", "Région"],
        ]);
      });

      layer.on("mouseover", () => layer.setStyle({ weight: 3, fillOpacity: 0.25 }));
      layer.on("mouseout", () => {
        if (layer !== state.activeLayer) layer.setStyle({ weight: 2, fillOpacity: 0.12 });
      });
    },
  }).addTo(state.map);

  state.regionsLayer._legendKey = "regions";
  state.layersControl.addOverlay(state.regionsLayer, "Régions");

  populateRegionSelect(geojson);
  appendStatus(`${geojson.features.length} région(s) chargée(s).`);
  setLegendCount("regions", geojson.features.length);
  enableLegendCheckbox("regions");
}

function populateRegionSelect(geojson) {
  const select = document.getElementById("region-select");
  geojson.features
    .map((f) => ({ name: getProp(f, REGION_NAME_KEYS), key: getProp(f, REGION_CODE_KEYS, getProp(f, REGION_NAME_KEYS)) }))
    .sort((a, b) => a.name.localeCompare(b.name))
    .forEach(({ name, key }) => {
      const option = document.createElement("option");
      option.value = key;
      option.textContent = name;
      select.appendChild(option);
    });
}

// ---------------------------------------------------------------------
// 3bis. Contrôles avancés — plugins Leaflet tiers branchés sur la carte :
//   - Leaflet.Locate  : géolocalisation de l'utilisateur (bouton "cible")
//   - Leaflet.fullscreen : bascule la carte en plein écran
//   - Leaflet-measure : mesure de distances et de surfaces à la souris
// Regroupés ici pour ne pas alourdir initMap().
// ---------------------------------------------------------------------
function initAdvancedControls() {
  // Géolocalisation : demande la position du navigateur, centre la carte
  // dessus et affiche un marqueur + cercle de précision. "untilPan" laisse
  // l'utilisateur reprendre la main sur la carte dès qu'il la déplace.
  if (L.control.locate) {
    L.control.locate({
      position: "topleft",
      setView: "untilPan",
      flyTo: true,
      initialZoomLevel: 12,
      drawCircle: true,
      drawMarker: true,
      showPopup: true,
      strings: {
        title: "Me géolocaliser",
        popup: "Vous êtes à environ {distance} {unit} de ce point.",
        outsideMapBoundsMsg: "Vous semblez être en dehors de la zone de la carte.",
      },
      locateOptions: { enableHighAccuracy: true, maxZoom: 14 },
    }).addTo(state.map);
  }

  // Plein écran (utile en présentation / sur mobile).
  if (L.Control.Fullscreen) {
    state.map.addControl(new L.Control.Fullscreen({
      title: { false: "Passer en plein écran", true: "Quitter le plein écran" },
      position: "topleft",
    }));
  }

  // Mesure de distances / surfaces directement sur la carte. La factory
  // L.control.measure() est l'API documentée du plugin ; on retombe sur le
  // constructeur L.Control.Measure direct si jamais elle n'est pas exposée.
  const measureOptions = {
    position: "topleft",
    primaryLengthUnit: "meters",
    secondaryLengthUnit: "kilometers",
    primaryAreaUnit: "sqmeters",
    secondaryAreaUnit: "hectares",
    activeColor: "#ef4444",
    completedColor: "#14b8a6",
    labels: {
      measure: "Mesurer",
      measureDistancesAndAreas: "Mesurer une distance ou une surface",
      createNewMeasurement: "Nouvelle mesure",
      startCreating: "Cliquez sur la carte pour commencer",
      continueLine: "Cliquez pour continuer, double-cliquez pour terminer",
      finishMeasurement: "Terminer",
      deleteMeasurement: "Supprimer la mesure",
      lengthMeasurementResult: "Distance",
      areaMeasurementResult: "Surface",
    },
  };
  if (typeof L.control.measure === "function") {
    L.control.measure(measureOptions).addTo(state.map);
  } else if (L.Control && L.Control.Measure) {
    new L.Control.Measure(measureOptions).addTo(state.map);
  }
}

// ---------------------------------------------------------------------
// 4. Couche Départements
// ---------------------------------------------------------------------
async function loadDepartements(regionKey = "") {
  setStatus("Chargement des départements…");

  // On charge une seule fois toute la couche, puis on filtre côté client
  // (fonctionne à la fois en mode local et en mode API).
  if (!state.allDepartementsGeoJSON) {
    state.allDepartementsGeoJSON = await fetchGeoJSON(departementsURL());
  }

  const filtered = regionKey
    ? {
        type: "FeatureCollection",
        features: state.allDepartementsGeoJSON.features.filter((f) => {
          // Comparaison stricte : les codes région sont numériques ("1" ne doit
          // pas matcher "10", "11"... d'où l'égalité exacte plutôt qu'un "includes").
          const link = String(getProp(f, DEPT_REGION_LINK_KEYS, "")).toLowerCase();
          return link === String(regionKey).toLowerCase();
        }),
      }
    : state.allDepartementsGeoJSON;

  if (state.departementsLayer) {
    // On désenregistre l'ancienne instance AVANT de la retirer, sinon le
    // 'layerremove' déclenché ci-dessous serait interprété par
    // onMapLayerToggle() comme un décochage volontaire de la case
    // "Départements" par l'utilisateur (alors que ce n'est qu'un
    // rafraîchissement interne dû au filtre région).
    delete state.departementsLayer._legendKey;
    state.layersControl.removeLayer(state.departementsLayer);
    state.map.removeLayer(state.departementsLayer);
  }

  state.departementsLayer = L.geoJSON(filtered, {
    style: () => ({
      color: "#b45309",
      weight: 1.5,
      fillColor: "#f59e0b",
      fillOpacity: 0.15,
    }),
    onEachFeature: (feature, layer) => {
      const name = getProp(feature, DEPT_NAME_KEYS);
      const code = getProp(feature, DEPT_CODE_KEYS);
      const region = getProp(feature, DEPT_REGION_LINK_KEYS);

      layer.bindPopup(buildPopupHTML(name, [
        ["Code", code],
        ["Région", region],
        ["Type", "Département"],
      ]));

      layer.on("click", () => {
        highlightLayer(layer);
        zoomToLayer(layer);
        showInfoPanel(name, [
          ["Code", code],
          ["Région", region],
          ["Type", "Département"],
        ]);
      });
    },
  });

  state.departementsLayer._legendKey = "departements";
  state.layersControl.addOverlay(state.departementsLayer, "Départements");
  if (state.departementsVisible) {
    state.departementsLayer.addTo(state.map);
  }

  populateDeptSelect(filtered);
  appendStatus(`${filtered.features.length} département(s) affiché(s).`);
  setLegendCount("departements", filtered.features.length);
  enableLegendCheckbox("departements");
}

function populateDeptSelect(geojson) {
  const select = document.getElementById("dept-select");
  select.innerHTML = "";

  if (geojson.features.length === 0) {
    select.appendChild(new Option("Aucun département trouvé", ""));
    return;
  }

  select.appendChild(new Option("— Sélectionnez un département —", ""));
  geojson.features
    .map((f) => ({ name: getProp(f, DEPT_NAME_KEYS), key: getProp(f, DEPT_CODE_KEYS, getProp(f, DEPT_NAME_KEYS)) }))
    .sort((a, b) => a.name.localeCompare(b.name))
    .forEach(({ name, key }) => select.appendChild(new Option(name, key)));
}

// ---------------------------------------------------------------------
// 4bis. Couche Infrastructures (Établissements scolaires, Centres de
// santé, Forages, Marchés, Équipements sportifs, Autres infrastructures
// publiques) — chaque type est une couche indépendante, activable/
// désactivable séparément (case à cocher = case du panneau "Couches" ou
// du contrôle Leaflet, les deux pilotent le même objet).
// ---------------------------------------------------------------------
function infraURL(key) {
  return CONFIG.USE_API
    ? `${CONFIG.API_BASE_URL}/infrastructures?type=${encodeURIComponent(key)}`
    : CONFIG.LOCAL_INFRA_PATHS[key];
}

// Crée, pour chaque type, un groupe de clusters VIDE. Les données ne sont
// récupérées qu'à la première activation (voir loadInfraData), pour ne
// jamais télécharger les 6 fichiers si l'utilisateur n'en affiche qu'un.
// Volontairement PAS enregistré dans state.layersControl (voir initMap) :
// seul le panneau latéral "Couches" les liste, pour ne pas dupliquer 6
// entrées dans le petit contrôle natif en bas à droite. Le toggle
// (checkbox du panneau -> map.addLayer/removeLayer) fonctionne à
// l'identique, avec ou sans registration dans le contrôle.
function initInfraGroups() {
  Object.entries(INFRA_TYPES).forEach(([key, type]) => {
    const group = L.markerClusterGroup({
      iconCreateFunction: makeClusterIconFn(type.color),
      showCoverageOnHover: false,
      spiderfyOnMaxZoom: true,
      maxClusterRadius: 50,
    });
    group._legendKey = `infra:${key}`;
    state.infraGroups[key] = group;
    state.infraLoaded[key] = false;
  });
}

function buildInfraPopup(feature, typeLabel) {
  const props = feature.properties || {};
  const title = props.nom && props.nom !== "" ? props.nom : typeLabel;
  const rows = [
    ["Type", props.type_label || typeLabel],
    ["Région", getNestedProp(feature, "region.nom")],
    ["Département", getNestedProp(feature, "departement.nom")],
    ["Commune", getNestedProp(feature, "commune.nom")],
    ["Quartier / Village", props.quartier_village || "—"],
    ["Milieu", props.milieu || "—"],
  ];
  return buildPopupHTML(title, rows);
}

// Récupère et affiche les points d'un type d'infrastructure. Appelée une
// seule fois par type, la première fois que sa case est cochée (le
// groupe de clusters, lui, est déjà sur la carte depuis onMapLayerToggle
// -> les marqueurs y apparaissent dès qu'ils sont ajoutés).
async function loadInfraData(key) {
  const type = INFRA_TYPES[key];
  const group = state.infraGroups[key];
  setStatus(`Chargement : ${type.label}…`);
  setLegendCount(`infra:${key}`, "…");

  try {
    const geojson = await fetchGeoJSON(infraURL(key));
    const features = type.filter ? geojson.features.filter(type.filter) : geojson.features;

    const icon = getInfraIcon(key);
    features.forEach((feature) => {
      if (!feature.geometry || feature.geometry.type !== "Point") return;
      const [lng, lat] = feature.geometry.coordinates;
      const marker = L.marker([lat, lng], { icon });
      marker.feature = feature; // exploité par la recherche multicritère (findSearchMatches)
      marker.bindPopup(buildInfraPopup(feature, type.label));
      group.addLayer(marker);
    });

    state.infraLoaded[key] = true;
    appendStatus(`${features.length} infrastructure(s) « ${type.label} » affichée(s).`);
    setLegendCount(`infra:${key}`, features.length);
  } catch (err) {
    console.error(err);
    setStatusError(`Erreur de chargement (${type.label}) : ${err.message}`);
    setLegendCount(`infra:${key}`, "erreur");
    // On désactive la couche puisque son chargement a échoué : évite une
    // case cochée qui laisse croire que la couche est active.
    state.map.removeLayer(group);
  }
}

// ---------------------------------------------------------------------
// 4ter. Panneau "Couches" — construit une fois (structure + écouteurs),
// puis seulement mis à jour ensuite (compteurs, cases cochées) : voir
// setLegendCount() / onMapLayerToggle() / enableLegendCheckbox().
// ---------------------------------------------------------------------
function legendItemHTML({ key, color, label, checked, disabled, note }) {
  const noteHTML = note ? `<p class="legend-item-note">${note}</p>` : "";
  return `
    <div class="legend-item">
      <input type="checkbox" id="layer-check-${key}" ${checked ? "checked" : ""} ${disabled ? "disabled" : ""} />
      <label for="layer-check-${key}">
        <span class="swatch" style="background:${color}"></span>
        ${label}
      </label>
      <span class="legend-count" id="layer-count-${key}"></span>
    </div>
    ${noteHTML}
  `;
}

function buildLayersPanel() {
  const container = document.getElementById("layers-groups");

  const adminGroupHTML = `
    <div class="legend-group">
      <p class="legend-group-title">Couches administratives</p>
      ${legendItemHTML({ key: "regions", color: "#14b8a6", label: "Régions", checked: true, disabled: true })}
      ${legendItemHTML({ key: "departements", color: "#f59e0b", label: "Départements", checked: true, disabled: true })}
      <div class="legend-item static">
        <span class="swatch" style="background:#ef4444"></span>
        Sélection active (surbrillance au clic)
      </div>
    </div>
  `;

  const infraItemsHTML = Object.entries(INFRA_TYPES)
    .map(([key, type]) => legendItemHTML({
      key: `infra:${key}`,
      color: type.color,
      label: type.label,
      checked: false,
      disabled: false,
      note: type.note,
    }))
    .join("");

  const infraGroupHTML = `
    <div class="legend-group">
      <p class="legend-group-title">Infrastructures</p>
      ${infraItemsHTML}
    </div>
  `;

  container.innerHTML = adminGroupHTML + infraGroupHTML;

  // Un seul type d'écouteur pour toutes les cases : elles se contentent
  // d'ajouter/retirer la couche de la carte, tout le reste (compteurs,
  // chargement des données, synchronisation du contrôle Leaflet) est
  // géré de façon centralisée par onMapLayerToggle().
  container.querySelectorAll('input[type="checkbox"]').forEach((checkbox) => {
    checkbox.addEventListener("change", (e) => {
      const key = e.target.id.replace("layer-check-", "");
      const layer = key === "regions" ? state.regionsLayer
        : key === "departements" ? state.departementsLayer
        : state.infraGroups[key.replace("infra:", "")];
      if (!layer) return;
      if (e.target.checked) {
        state.map.addLayer(layer);
      } else {
        state.map.removeLayer(layer);
      }
    });
  });
}

function setLegendCount(key, value) {
  const el = document.getElementById(`layer-count-${key}`);
  if (el) el.textContent = value === "" || value === null || value === undefined ? "" : String(value);
}

function enableLegendCheckbox(key) {
  const checkbox = document.getElementById(`layer-check-${key}`);
  if (checkbox) checkbox.disabled = false;
}

// ---------------------------------------------------------------------
// 4quater. Recherche multicritère — combine un texte libre, un type de
// couche (Régions / Départements / un des 6 types d'infrastructures) et
// la région/département déjà sélectionnés dans le panneau "Rechercher"
// ci-dessus. Les couches d'infrastructures pas encore cochées sont
// chargées à la volée (une seule fois, comme pour le panneau "Couches").
// ---------------------------------------------------------------------
function escapeHTML(str) {
  const div = document.createElement("div");
  div.textContent = str == null ? "" : String(str);
  return div.innerHTML;
}

async function performSearch() {
  const resultsBox = document.getElementById("search-results");
  const textRaw = document.getElementById("search-text").value.trim();
  const textNorm = normalizeName(textRaw);
  const typeVal = document.getElementById("search-type").value; // "", "admin:region", "admin:departement", "infra:<key>"

  const regionSelect = document.getElementById("region-select");
  const deptSelect = document.getElementById("dept-select");
  const regionCodeVal = regionSelect.value;
  const deptCodeVal = deptSelect.value;
  // Les fichiers d'infrastructures utilisent un référentiel de codes région
  // différent de regions.geojson (cf. commentaire en tête de statistiques.js) :
  // pour elles, on compare par nom normalisé plutôt que par code.
  const regionNameNorm = regionCodeVal ? normalizeName(regionSelect.options[regionSelect.selectedIndex].text) : "";
  const deptNameNorm = deptCodeVal ? normalizeName(deptSelect.options[deptSelect.selectedIndex].text) : "";

  resultsBox.innerHTML = '<p class="placeholder">Recherche en cours…</p>';

  const results = [];
  const wantAdminRegion = !typeVal || typeVal === "admin:region";
  const wantAdminDept = !typeVal || typeVal === "admin:departement";
  const infraKeysWanted = typeVal.startsWith("infra:")
    ? [typeVal.slice("infra:".length)]
    : (!typeVal ? Object.keys(INFRA_TYPES) : []);

  // --- Régions ---
  if (wantAdminRegion && state.regionsLayer) {
    state.regionsLayer.eachLayer((layer) => {
      const name = getProp(layer.feature, REGION_NAME_KEYS);
      if (textNorm && !normalizeName(name).includes(textNorm)) return;
      results.push({
        label: name,
        sublabel: "Région",
        onSelect: () => {
          highlightLayer(layer);
          zoomToLayer(layer);
          showInfoPanel(name, [["Code", getProp(layer.feature, REGION_CODE_KEYS)], ["Type", "Région"]]);
        },
      });
    });
  }

  // --- Départements --- (recherche dans l'ensemble complet, indépendamment
  // du filtre région actuellement affiché, pour ne rien manquer)
  if (wantAdminDept && state.allDepartementsGeoJSON) {
    state.allDepartementsGeoJSON.features.forEach((feature) => {
      const name = getProp(feature, DEPT_NAME_KEYS);
      if (textNorm && !normalizeName(name).includes(textNorm)) return;
      if (regionCodeVal) {
        const link = String(getProp(feature, DEPT_REGION_LINK_KEYS, "")).toLowerCase();
        if (link !== String(regionCodeVal).toLowerCase()) return;
      }
      const deptCode = getProp(feature, DEPT_CODE_KEYS);
      results.push({
        label: name,
        sublabel: `Département — ${getProp(feature, DEPT_REGION_LINK_KEYS)}`,
        onSelect: async () => {
          let layer = state.departementsLayer && findLayerByFeatureKey(state.departementsLayer, DEPT_CODE_KEYS, deptCode);
          if (!layer) {
            await loadDepartements(""); // le département visé n'est pas dans la couche filtrée actuelle
            layer = findLayerByFeatureKey(state.departementsLayer, DEPT_CODE_KEYS, deptCode);
          }
          if (layer) {
            highlightLayer(layer);
            zoomToLayer(layer);
            showInfoPanel(name, [
              ["Code", deptCode],
              ["Région", getProp(feature, DEPT_REGION_LINK_KEYS)],
              ["Type", "Département"],
            ]);
          }
        },
      });
    });
  }

  // --- Infrastructures --- (charge d'abord les types manquants)
  if (infraKeysWanted.length) {
    await Promise.all(
      infraKeysWanted.map((key) => (state.infraLoaded[key] ? Promise.resolve() : loadInfraData(key)))
    );

    infraKeysWanted.forEach((key) => {
      const group = state.infraGroups[key];
      const type = INFRA_TYPES[key];
      group.eachLayer((marker) => {
        const feature = marker.feature;
        if (!feature) return;
        const props = feature.properties || {};
        const name = props.nom && props.nom !== "" ? props.nom : type.label;

        if (textNorm && !normalizeName(name).includes(textNorm)) return;
        if (regionNameNorm && normalizeName(getNestedProp(feature, "region.nom", "")) !== regionNameNorm) return;
        if (deptNameNorm && normalizeName(getNestedProp(feature, "departement.nom", "")) !== deptNameNorm) return;

        results.push({
          label: name,
          sublabel: `${type.label} — ${getNestedProp(feature, "commune.nom")}`,
          onSelect: () => {
            if (!state.map.hasLayer(group)) state.map.addLayer(group);
            // zoomToShowLayer (API Leaflet.markercluster) gère le dé-clustering
            // automatique si le marqueur est actuellement regroupé.
            group.zoomToShowLayer(marker, () => marker.openPopup());
          },
        });
      });
    });
  }

  renderSearchResults(results, textRaw);
}

function renderSearchResults(results, textRaw) {
  const box = document.getElementById("search-results");
  if (!results.length) {
    box.innerHTML = `<p class="placeholder">Aucun résultat${textRaw ? ` pour « ${escapeHTML(textRaw)} »` : ""}.</p>`;
    return;
  }

  const MAX = 40;
  const shown = results.slice(0, MAX);
  box.innerHTML = `
    <p class="search-count">${results.length} résultat(s)${results.length > MAX ? ` — ${MAX} premiers affichés` : ""}</p>
    <ul class="search-result-list"></ul>
  `;
  const list = box.querySelector(".search-result-list");
  shown.forEach((r) => {
    const li = document.createElement("li");
    li.className = "search-result-item";
    li.innerHTML = `<span class="srl-name">${escapeHTML(r.label)}</span><span class="srl-sub">${escapeHTML(r.sublabel)}</span>`;
    li.addEventListener("click", () => {
      Promise.resolve(r.onSelect()).catch((err) => console.error(err));
    });
    list.appendChild(li);
  });
}

function wireSearchUI() {
  const btn = document.getElementById("search-btn");
  const input = document.getElementById("search-text");

  btn.addEventListener("click", () => {
    performSearch().catch((err) => {
      console.error(err);
      document.getElementById("search-results").innerHTML =
        `<p class="placeholder">Erreur pendant la recherche : ${escapeHTML(err.message)}</p>`;
    });
  });

  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") btn.click();
  });
}

// ---------------------------------------------------------------------
// 5. Interactions carte <-> UI
// ---------------------------------------------------------------------
function zoomToLayer(layer) {
  if (layer.getBounds) {
    state.map.fitBounds(layer.getBounds(), { maxZoom: 11, padding: [20, 20] });
  }
}

function highlightLayer(layer) {
  if (state.activeLayer && state.activeLayer !== layer) {
    resetLayerStyle(state.activeLayer);
  }
  layer.setStyle({ color: "#ef4444", weight: 3, fillOpacity: 0.3 });
  state.activeLayer = layer;
}

function resetLayerStyle(layer) {
  const isDept = state.departementsLayer && state.departementsLayer.hasLayer(layer);
  layer.setStyle(
    isDept
      ? { color: "#b45309", weight: 1.5, fillOpacity: 0.15 }
      : { color: "#0d9488", weight: 2, fillOpacity: 0.12 }
  );
}

function findLayerByFeatureKey(geoJsonLayer, keys, value) {
  let found = null;
  geoJsonLayer.eachLayer((layer) => {
    if (String(getProp(layer.feature, keys)) === String(value)) found = layer;
  });
  return found;
}

function buildPopupHTML(title, rows) {
  const rowsHTML = rows
    .map(([k, v]) => `<div class="popup-row"><b>${k}:</b> ${v}</div>`)
    .join("");
  return `<div class="popup-title">${title}</div>${rowsHTML}`;
}

function showInfoPanel(title, rows) {
  const panel = document.getElementById("info-panel");
  const rowsHTML = rows
    .map(([k, v]) => `<div class="info-row"><span class="k">${k}</span><span class="v">${v}</span></div>`)
    .join("");
  panel.innerHTML = `<h2>Informations</h2><div class="info-row"><span class="k">Nom</span><span class="v">${title}</span></div>${rowsHTML}`;
}

function setStatus(text) {
  const el = document.getElementById("status-text");
  el.textContent = text;
  el.className = "status";
}
function appendStatus(text) {
  const el = document.getElementById("status-text");
  el.textContent = text;
  el.className = "status ok";
}
function setStatusError(text) {
  const el = document.getElementById("status-text");
  el.textContent = text;
  el.className = "status error";
}

// ---------------------------------------------------------------------
// 6. Écouteurs des listes déroulantes
// ---------------------------------------------------------------------
function wireUI() {
  const regionSelect = document.getElementById("region-select");
  const deptSelect = document.getElementById("dept-select");
  const resetBtn = document.getElementById("reset-btn");

  regionSelect.addEventListener("change", async (e) => {
    const regionKey = e.target.value;

    if (!regionKey) {
      await loadDepartements("");
      state.map.setView([14.4974, -14.4524], 7);
      return;
    }

    const layer = findLayerByFeatureKey(state.regionsLayer, REGION_CODE_KEYS, regionKey)
      || findLayerByFeatureKey(state.regionsLayer, REGION_NAME_KEYS, regionKey);
    if (layer) {
      highlightLayer(layer);
      zoomToLayer(layer);
      const name = getProp(layer.feature, REGION_NAME_KEYS);
      showInfoPanel(name, [["Code", getProp(layer.feature, REGION_CODE_KEYS)], ["Type", "Région"]]);
    }

    try {
      await loadDepartements(regionKey);
    } catch (err) {
      setStatusError(err.message);
    }
  });

  deptSelect.addEventListener("change", (e) => {
    const deptKey = e.target.value;
    if (!deptKey || !state.departementsLayer) return;

    const layer = findLayerByFeatureKey(state.departementsLayer, DEPT_CODE_KEYS, deptKey)
      || findLayerByFeatureKey(state.departementsLayer, DEPT_NAME_KEYS, deptKey);
    if (layer) {
      highlightLayer(layer);
      zoomToLayer(layer);
      const name = getProp(layer.feature, DEPT_NAME_KEYS);
      showInfoPanel(name, [
        ["Code", getProp(layer.feature, DEPT_CODE_KEYS)],
        ["Région", getProp(layer.feature, DEPT_REGION_LINK_KEYS)],
        ["Type", "Département"],
      ]);
    }
  });

  resetBtn.addEventListener("click", () => {
    regionSelect.value = "";
    deptSelect.value = "";
    document.getElementById("search-text").value = "";
    document.getElementById("search-type").value = "";
    document.getElementById("search-results").innerHTML = "";

    // Désactive toutes les couches d'infrastructures actuellement visibles
    // (retirer la couche déclenche onMapLayerToggle, qui décoche la case
    // correspondante automatiquement).
    Object.values(state.infraGroups).forEach((group) => {
      if (state.map.hasLayer(group)) state.map.removeLayer(group);
    });

    // Réaffiche systématiquement régions/départements (cases toujours
    // cochées par défaut, cf. buildLayersPanel).
    state.departementsVisible = true;
    if (state.regionsLayer && !state.map.hasLayer(state.regionsLayer)) {
      state.map.addLayer(state.regionsLayer);
    }

    if (state.activeLayer) {
      resetLayerStyle(state.activeLayer);
      state.activeLayer = null;
    }
    loadDepartements("");
    state.map.setView([14.4974, -14.4524], 7);
    document.getElementById("info-panel").innerHTML =
      '<h2>Informations</h2><p class="placeholder">Cliquez sur une région ou un département sur la carte, ou utilisez les listes ci-dessus.</p>';

    // Notifie les modules greffés sur ces <select> (ex. js/territoire.js :
    // tableau dynamique + niveau communauté rurale) sans dépendre d'eux —
    // ils écoutent déjà cet événement "change" de leur côté.
    const communeSelect = document.getElementById("commune-select");
    if (communeSelect) communeSelect.value = "";
    regionSelect.dispatchEvent(new Event("change"));
  });
}

// ---------------------------------------------------------------------
// 7. Démarrage
// ---------------------------------------------------------------------
async function start() {
  initMap();
  wireUI();
  wireSearchUI();
  initInfraGroups();
  buildLayersPanel();
  try {
    await loadRegions();
    await loadDepartements("");
  } catch (err) {
    console.error(err);
    setStatusError(
      "Erreur de chargement des données. Vérifie que data/regions.geojson " +
      "et data/departements.geojson existent (ou que l'API tourne si USE_API = true)."
    );
  }
}

document.addEventListener("DOMContentLoaded", start);
