/* Révèle les éléments .reveal quand ils entrent dans le viewport, avec un
   décalage progressif entre les éléments d'un même groupe (data-group).
   Les nombres (.num) à l'intérieur d'un élément révélé sont en plus
   animés en comptage progressif, de 0 jusqu'à leur valeur finale. */

// Anime un élément .num de 0 jusqu'à la valeur lue dans son propre texte
// (gère le séparateur de milliers français "8 756" ou "2 493").
function animateCountUp(el, duration = 1200) {
  const target = parseInt(el.textContent.replace(/[^\d]/g, ""), 10);
  if (Number.isNaN(target)) return; // valeur non numérique (ex: "—") : on laisse tel quel

  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    el.textContent = target.toLocaleString("fr-FR"); // pas d'animation, valeur finale directe
    return;
  }

  const start = performance.now();

  function tick(now) {
    const progress = Math.min((now - start) / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic : rapide au début, ralentit à l'arrivée
    const current = Math.round(eased * target);
    el.textContent = current.toLocaleString("fr-FR");
    if (progress < 1) {
      requestAnimationFrame(tick);
    } else {
      el.textContent = target.toLocaleString("fr-FR"); // valeur exacte finale, sans arrondi résiduel
    }
  }

  requestAnimationFrame(tick);
}

document.addEventListener("DOMContentLoaded", () => {
  const items = document.querySelectorAll(".reveal");

  const groups = {};
  items.forEach((el) => {
    const group = el.dataset.group || "default";
    groups[group] = groups[group] || [];
    groups[group].push(el);
  });
  Object.values(groups).forEach((els) => {
    els.forEach((el, i) => {
      el.style.transitionDelay = `${i * 90}ms`;
    });
  });

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("in-view");
          const numEl = entry.target.querySelector(".num");
          if (numEl) animateCountUp(numEl);
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );

  items.forEach((el) => observer.observe(el));
});
