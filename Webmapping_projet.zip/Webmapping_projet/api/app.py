"""
SITS Sénégal — API REST (Python / Flask)
=========================================

Implémente exactement le contrat d'API documenté en commentaire en tête de
../js/app.js et dans ../js/territoire.js, pour que le frontend n'ait rien à
changer : il suffit de passer CONFIG.USE_API à true dans js/app.js (déjà fait
par défaut) et de lancer cette API sur le port 5000.

Les données ne sont pas dupliquées : cette API lit les mêmes fichiers
GeoJSON que le mode "fichiers locaux", dans ../data/, et les sert simplement
en JSON via des routes REST — avec les mêmes filtres que ceux appliqués
côté client (type d'infrastructure, région, département).

Lancement :
    pip install -r requirements.txt
    python app.py
    -> API disponible sur http://127.0.0.1:5000/api

Endpoints
---------
GET /api/regions
GET /api/regions/search?q=<texte>
GET /api/departements[?region=<code_ou_nom_region>]
GET /api/departements/search?q=<texte>
GET /api/communautes-rurales[?departement=<code_ou_nom_departement>]
GET /api/infrastructures?type=<ecoles|sante|forage|marche|sport|autres>
"""

import json
import os
import unicodedata

from flask import Flask, jsonify, request
from flask_cors import CORS

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "..", "data")

app = Flask(__name__)
CORS(app)  # le frontend statique (port 8000) et l'API (port 5000) sont sur
           # des origines différentes : sans CORS, le navigateur bloquerait fetch().

# ---------------------------------------------------------------------------
# Chargement des fichiers GeoJSON — mis en cache en mémoire au premier accès
# (les fichiers ne changent pas pendant que l'API tourne).
# ---------------------------------------------------------------------------
_cache = {}


def load_geojson(filename):
    if filename not in _cache:
        path = os.path.join(DATA_DIR, filename)
        with open(path, encoding="utf-8") as f:
            _cache[filename] = json.load(f)
    return _cache[filename]


def get_prop(feature, keys, default=None):
    """Équivalent Python de getProp() dans app.js : renvoie la première clé
    présente et non vide parmi `keys` dans feature['properties']."""
    props = feature.get("properties") or {}
    for key in keys:
        value = props.get(key)
        if value not in (None, ""):
            return value
    return default


def normalize_name(value):
    """Équivalent Python de normalizeName() dans app.js/statistiques.js :
    majuscules, sans accents, tirets -> espaces — pour comparer par nom
    quand les référentiels de codes diffèrent entre jeux de données."""
    text = str(value or "")
    text = "".join(
        c for c in unicodedata.normalize("NFD", text) if unicodedata.category(c) != "Mn"
    )
    text = text.upper().replace("-", " ")
    return " ".join(text.split())


def feature_collection(features):
    return {"type": "FeatureCollection", "features": features}


# ---------------------------------------------------------------------------
# Régions
# ---------------------------------------------------------------------------
REGION_NAME_KEYS = ["nom", "NOM_REG", "name"]


@app.get("/api/regions")
def get_regions():
    return jsonify(load_geojson("regions.geojson"))


@app.get("/api/regions/search")
def search_regions():
    q = normalize_name(request.args.get("q", ""))
    data = load_geojson("regions.geojson")
    if not q:
        return jsonify(data)
    matches = [f for f in data["features"] if q in normalize_name(get_prop(f, REGION_NAME_KEYS, ""))]
    return jsonify(feature_collection(matches))


# ---------------------------------------------------------------------------
# Départements
# ---------------------------------------------------------------------------
DEPT_NAME_KEYS = ["nom", "NOM_DEPT", "name"]
DEPT_REGION_LINK_KEYS = ["region_code", "region_nom"]


@app.get("/api/departements")
def get_departements():
    data = load_geojson("departements.geojson")
    region = request.args.get("region", "").strip()
    if not region:
        return jsonify(data)
    region_norm = normalize_name(region)
    matches = [
        f for f in data["features"]
        if str(get_prop(f, DEPT_REGION_LINK_KEYS, "")).lower() == region.lower()
        or normalize_name(get_prop(f, DEPT_REGION_LINK_KEYS, "")) == region_norm
    ]
    return jsonify(feature_collection(matches))


@app.get("/api/departements/search")
def search_departements():
    q = normalize_name(request.args.get("q", ""))
    data = load_geojson("departements.geojson")
    if not q:
        return jsonify(data)
    matches = [f for f in data["features"] if q in normalize_name(get_prop(f, DEPT_NAME_KEYS, ""))]
    return jsonify(feature_collection(matches))


# ---------------------------------------------------------------------------
# Communautés rurales (3e niveau de la cascade, utilisé par js/territoire.js)
# ---------------------------------------------------------------------------
COMMUNE_DEPT_CODE_KEYS = ["departement_code"]
COMMUNE_DEPT_NAME_KEYS = ["departement_nom"]


@app.get("/api/communautes-rurales")
def get_communes_rurales():
    data = load_geojson("communes_rurales.geojson")
    departement = request.args.get("departement", "").strip()
    if not departement:
        return jsonify(data)
    dep_norm = normalize_name(departement)
    matches = [
        f for f in data["features"]
        if str(get_prop(f, COMMUNE_DEPT_CODE_KEYS, "")) == departement
        or normalize_name(get_prop(f, COMMUNE_DEPT_NAME_KEYS, "")) == dep_norm
    ]
    return jsonify(feature_collection(matches))


# ---------------------------------------------------------------------------
# Infrastructures — 6 types imposés par le cahier des charges. "sport" n'a
# pas de fichier dédié : filtré côté serveur à partir de loisirs.geojson,
# exactement comme isSportFeature() le fait côté client dans app.js.
# ---------------------------------------------------------------------------
INFRA_FILES = {
    "ecoles": "lycee.geojson",
    "sante": "centre_sante.geojson",
    "forage": "forage.geojson",
    "marche": "marche.geojson",
    "sport": "loisirs.geojson",
    "autres": "parking.geojson",
}
SPORT_KEYWORDS = ("PISCINE", "AIRE DE JEUX", "GYMNASE")


def is_sport_feature(feature):
    nom = normalize_name(get_prop(feature, ["nom"], ""))
    return any(keyword in nom for keyword in SPORT_KEYWORDS)


@app.get("/api/infrastructures")
def get_infrastructures():
    infra_type = request.args.get("type", "")
    if infra_type not in INFRA_FILES:
        return jsonify({
            "error": "Paramètre 'type' invalide ou manquant.",
            "types_valides": list(INFRA_FILES.keys()),
        }), 400

    data = load_geojson(INFRA_FILES[infra_type])
    if infra_type == "sport":
        data = feature_collection([f for f in data["features"] if is_sport_feature(f)])
    return jsonify(data)


# ---------------------------------------------------------------------------
# Racine — petite page de vérification manuelle
# ---------------------------------------------------------------------------
@app.get("/api")
def api_root():
    return jsonify({
        "message": "API SITS Sénégal — voir la liste des routes ci-dessous.",
        "routes": [
            "/api/regions",
            "/api/regions/search?q=",
            "/api/departements",
            "/api/departements?region=",
            "/api/departements/search?q=",
            "/api/communautes-rurales",
            "/api/communautes-rurales?departement=",
            "/api/infrastructures?type=ecoles|sante|forage|marche|sport|autres",
        ],
    })


if __name__ == "__main__":
    app.run(debug=True, port=5000)
