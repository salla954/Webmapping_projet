@echo off
title SITS Senegal - Serveur de fichiers (port 8000)
cd /d "%~dp0"

echo =========================================================
echo   SITS Senegal - demarrage des serveurs locaux
echo =========================================================
echo.
echo Deux fenetres vont s'ouvrir : l'API (port 5000) et le
echo serveur de fichiers (port 8000, cette fenetre-ci).
echo Fermez les DEUX fenetres pour tout arreter.
echo.

where python >nul 2>nul
if %errorlevel%==0 (
    set PYCMD=python
) else (
    where python3 >nul 2>nul
    if %errorlevel%==0 (
        set PYCMD=python3
    ) else (
        echo [ERREUR] Python n'a pas ete trouve sur cet ordinateur.
        echo Installez Python depuis https://www.python.org/downloads/
        echo puis relancez ce fichier.
        pause
        exit /b 1
    )
)

%PYCMD% -c "import flask, flask_cors" >nul 2>nul
if not %errorlevel%==0 (
    echo Installation des dependances de l'API Flask...
    %PYCMD% -m pip install -r api\requirements.txt
    echo.
)

echo Demarrage de l'API Flask (port 5000)...
start "SITS API (Flask - port 5000)" cmd /k "cd api && %PYCMD% app.py"

timeout /t 2 /nobreak >nul

start "" http://localhost:8000/accueil.html

echo Demarrage du serveur de fichiers (port 8000)...
%PYCMD% -m http.server 8000
