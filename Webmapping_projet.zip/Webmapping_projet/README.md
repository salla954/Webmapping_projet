# SITS Sénégal — Système d'Information Territorial

Projet Webmapping (L3 Géomatique UIDT) : application cartographique
Leaflet du Sénégal — régions, départements, communautés rurales et 6
couches d'infrastructures publiques — consommant une API REST développée
en Python (Flask), plus une page de statistiques territoriales.

## ⚠️ Démarrage — obligatoire

L'application a besoin de **deux serveurs locaux** : l'API Flask (données)
et un serveur de fichiers (pages HTML/CSS/JS). Un double-clic direct sur
`index.html` ne fonctionnera pas (le navigateur bloque `fetch()` en
`file://`, et il n'y a alors aucune API à interroger).

- **Windows** : double-cliquez sur `demarrer.bat`
- **macOS / Linux** : `chmod +x demarrer.sh && ./demarrer.sh` (ou
  double-clic selon la configuration de votre système)

Le script installe automatiquement les dépendances Python de l'API si
besoin (Flask, flask-cors), démarre l'API sur le port 5000, le site sur le
port 8000, puis ouvre `http://localhost:8000/accueil.html`.

Sous Windows, **deux fenêtres** s'ouvrent (API + serveur de fichiers) :
fermez les deux pour tout arrêter. Sous macOS/Linux, un seul terminal
suffit (Ctrl+C arrête les deux serveurs).

### Démarrage manuel (sans les scripts)
```
cd api
pip install -r requirements.txt
python app.py            # laisser tourner (terminal 1) — API sur :5000

# dans un second terminal, à la racine du projet :
python3 -m http.server 8000   # site sur :8000
```
Puis ouvrir `http://localhost:8000/accueil.html`.

## Architecture

```
Webmapping_projet/
├── index.html            page carte (Leaflet)
├── accueil.html           page d'accueil
├── statistiques.html      page statistiques
├── css/                   style.css (partagé) + accueil.css + statistiques.css
├── js/
│   ├── app.js              carte : régions/départements/infrastructures, recherche, contrôles avancés
│   ├── territoire.js        tableau dynamique + niveau "communauté rurale" (se greffe sur app.js)
│   ├── statistiques.js      page statistiques
│   ├── accueil.js / theme.js
├── data/                  GeoJSON sources (régions, départements, communes rurales, infrastructures)
├── api/
│   ├── app.py              API REST Flask — sert les données de data/ en JSON
│   └── requirements.txt
├── demarrer.bat / demarrer.sh
```

Le frontend peut fonctionner dans deux modes, pilotés par `CONFIG.USE_API`
en tête de `js/app.js` :
- `true` (réglage actuel) : les données sont récupérées via l'API REST Flask
  (`api/app.py`), en AJAX (`fetch`) — c'est le mode utilisé par défaut.
- `false` : lecture directe des fichiers GeoJSON de `data/`, utile pour
  travailler sans lancer l'API pendant le développement.
Aucune ligne de `js/app.js` ou `js/territoire.js` n'a besoin de changer
pour basculer de l'un à l'autre : seules les fonctions `regionsURL()`,
`departementsURL()`, `infraURL()`, `communesURL()` construisent une URL
différente selon ce réglage.

## Conformité au cahier des charges

| Exigence | État |
|---|---|
| Interface responsive, menu latéral, carte Leaflet, zone d'infos | ✅ |
| Tableau dynamique des données territoriales | ✅ (`js/territoire.js`, tiroir sous la carte, bouton "📊 Tableau des données") |
| Recherche par région / département avec zoom auto + popup | ✅ |
| Consommation d'API REST Python en AJAX (régions, départements, infrastructures) | ✅ (`api/app.py`, Flask) |
| Couche Régions / Départements : symbologie, popup | ✅ |
| Couche Infrastructures (6 types), symbole + popup | ✅ |
| Navigation (zoom, déplacement), gestion des couches, légende | ✅ |
| **Bonus** — Géolocalisation | ✅ (Leaflet.Locate) |
| **Bonus** — Recherche multicritère | ✅ (nom + type + région/département) |
| **Bonus** — Clustering des infrastructures | ✅ (Leaflet.markercluster) |
| **Bonus** — Statistiques interactives | ✅ (filtre région, graphique + donut chart) |
| **Bonus** — Fonds de carte supplémentaires | ✅ (5 fonds : OSM, CARTO clair/sombre, relief, satellite) |
| **Bonus** — Plugins Leaflet avancés | ✅ (locate, fullscreen, measure, markercluster) |
| Rapport technique (5–10 pages) | ⬜ à rédiger séparément (hors code) |

## Endpoints de l'API (`api/app.py`)

```
GET /api/regions
GET /api/regions/search?q=<texte>
GET /api/departements[?region=<code_ou_nom>]
GET /api/departements/search?q=<texte>
GET /api/communautes-rurales[?departement=<code_ou_nom>]
GET /api/infrastructures?type=<ecoles|sante|forage|marche|sport|autres>
```
