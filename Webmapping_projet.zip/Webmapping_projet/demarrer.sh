#!/bin/bash
# SITS Sénégal — démarre l'API Flask (port 5000) ET le serveur de fichiers
# (port 8000), puis ouvre le site dans le navigateur.
# Nécessaire : les navigateurs bloquent fetch() en file:// (double-clic sur
# index.html), et le frontend consomme désormais une vraie API REST Python.
cd "$(dirname "$0")"

echo "========================================================="
echo "  SITS Sénégal - démarrage des serveurs locaux"
echo "========================================================="
echo
echo "Ne fermez pas ce terminal tant que vous utilisez le site."
echo "Pour tout arrêter (API + serveur de fichiers) : Ctrl+C."
echo

PYCMD=""
if command -v python3 &>/dev/null; then
  PYCMD="python3"
elif command -v python &>/dev/null; then
  PYCMD="python"
else
  echo "[ERREUR] Python n'a pas été trouvé sur cet ordinateur."
  echo "Installez Python (https://www.python.org/downloads/) puis relancez ce script."
  exit 1
fi

# Installe les dépendances de l'API (Flask) si nécessaire, une seule fois.
if ! $PYCMD -c "import flask, flask_cors" &>/dev/null; then
  echo "Installation des dépendances de l'API (Flask)..."
  $PYCMD -m pip install -r api/requirements.txt
  echo
fi

# Démarre l'API Flask (port 5000) en arrière-plan.
( cd api && $PYCMD app.py ) &
API_PID=$!
trap "echo; echo Arrêt de l'API...; kill $API_PID 2>/dev/null" EXIT

( sleep 1.5
  URL="http://localhost:8000/accueil.html"
  if command -v open &>/dev/null; then open "$URL"          # macOS
  elif command -v xdg-open &>/dev/null; then xdg-open "$URL" # Linux
  fi
) &

echo "Démarrage du serveur de fichiers (port 8000)..."
$PYCMD -m http.server 8000
