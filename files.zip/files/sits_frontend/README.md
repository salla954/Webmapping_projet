# SITS — Partie Symbologie / Popups / Bonus

Démo autonome pour tester et valider ta partie du projet avant fusion avec le
reste de l'équipe.

## Contenu

| Fichier | Contenu | Ta partie ? |
|---|---|---|
| `js/symbology.js` | Couleurs/icônes par type d'infrastructure, fabrication des icônes Leaflet, légende | ✅ Symbologie |
| `js/popups.js` | Contenu des popups + statistiques dynamiques (AJAX) | ✅ Popups |
| `js/bonus.js` | Géolocalisation, fonds de carte, clustering, graphique de stats | ✅ Bonus |
| `js/app.js` | Glue de démo (init carte, appels API, formulaire) | ⚠️ À fusionner avec le `app.js` du groupe |
| `index.html`, `css/style.css` | Page de test | ⚠️ Démo — le groupe a sûrement déjà une structure de page |

## Comment tester

1. Lance l'API (voir le dossier `sits_api`) :
   ```bash
   cd sits_api
   pip install fastapi uvicorn --break-system-packages
   uvicorn app.main:app --reload --port 8000
   ```
2. Ouvre `index.html` dans le navigateur (double-clic, ou `Live Server` dans VS Code).
   Si l'API tourne sur une autre adresse, change `API_BASE_URL` en haut de `js/app.js`.

## Comment fusionner avec le fichier du groupe

- Copie `js/symbology.js`, `js/popups.js` et `js/bonus.js` tels quels dans le
  projet commun (ordre de chargement : Leaflet → markercluster → symbology.js
  → popups.js → bonus.js → app.js du groupe).
- Dans le `app.js` commun, à l'endroit où les couches Leaflet sont créées à
  partir des données de l'API, remplace la création de marqueurs simples par :
  ```js
  L.geoJSON(geojson, {
    pointToLayer: (feature, latlng) => L.marker(latlng, { icon: getInfraIcon(feature.properties.type) }),
    onEachFeature: bindInfraPopup,
  });
  ```
  ou, avec clustering, utilise directement `buildClusterLayer(type, geojson)`.
- Pour la légende : appelle `buildLegend("id-du-conteneur", counts, callback)`.
- Pour les bonus : appelle `addGeolocationControl(map)`, `buildBasemaps()`,
  et `renderStatsChart("id-du-canvas", counts)` où c'est pertinent dans la
  structure du groupe.
- Dans `index.html` du groupe, ajoute les balises `<link>`/`<script>` CDN
  listées en haut de ce `index.html` (Leaflet.markercluster, Font Awesome,
  Chart.js) si elles n'y sont pas déjà.

## Notes pour le rapport technique

Pense à mentionner dans le rapport :
- Le choix de symboles/couleurs par catégorie (accessibilité, cohérence).
- Le mécanisme AJAX des popups (stat "autres infrastructures du même type
  dans le département", calculée via l'API à l'ouverture de la popup).
- Les bonus implémentés : géolocalisation, clustering (Leaflet.markercluster),
  recherche multicritère, statistiques interactives (Chart.js), fonds de
  carte supplémentaires (Carto, Esri, OpenTopoMap).
