/* ==========================================================================
   symbology.js
   Partie "Symbologie" : définit, pour chaque type d'infrastructure, sa
   couleur, son icône (Font Awesome) et son libellé, puis fournit les
   fonctions pour construire des icônes Leaflet et une légende dynamique.

   -> À intégrer dans le fichier commun app.js du groupe : ce fichier n'a
      besoin que de Leaflet chargé avant lui. Aucune dépendance à l'API.
   ========================================================================== */

const SYMBOLOGY = {
  centre_sante: { color: "#C0392B", icon: "fa-hospital",          label: "Centre de santé" },
  forage:       { color: "#2E86AB", icon: "fa-droplet",           label: "Forage" },
  hotelerie:    { color: "#7D5BA6", icon: "fa-bed",                label: "Hôtellerie" },
  loisirs:      { color: "#4C9A6B", icon: "fa-futbol",             label: "Loisirs" },
  lycee:        { color: "#C99A1E", icon: "fa-graduation-cap",     label: "Lycée" },
  marche:       { color: "#D9762E", icon: "fa-basket-shopping",    label: "Marché" },
  parking:      { color: "#5B6B73", icon: "fa-square-parking",     label: "Parking" },
};

/**
 * Construit une icône Leaflet (divIcon) stylée pour un type d'infrastructure donné.
 * Utilise une "pin" colorée (forme de goutte) + une icône Font Awesome au centre.
 */
function getInfraIcon(type) {
  const s = SYMBOLOGY[type] || { color: "#333", icon: "fa-location-dot" };
  return L.divIcon({
    className: "custom-marker",
    html: `<div class="marker-pin" style="background:${s.color}">
             <i class="fa-solid ${s.icon}"></i>
           </div>`,
    iconSize: [26, 26],
    iconAnchor: [13, 26],
    popupAnchor: [0, -24],
  });
}

/** Couleur associée à un type (fallback gris si type inconnu). */
function getInfraColor(type) {
  return (SYMBOLOGY[type] || { color: "#333" }).color;
}

/** Libellé lisible d'un type. */
function getInfraLabel(type) {
  return (SYMBOLOGY[type] || {}).label || type;
}

/**
 * Construit la légende interactive dans le conteneur donné (id ou élément).
 * `counts` : { type: nombre } pour afficher un compteur par couche.
 * `onToggle(type, checked)` : callback appelé quand on coche/décoche un type.
 */
function buildLegend(container, counts, onToggle) {
  const el = typeof container === "string" ? document.getElementById(container) : container;
  el.innerHTML = "";
  Object.keys(SYMBOLOGY).forEach((type) => {
    const s = SYMBOLOGY[type];
    const row = document.createElement("label");
    row.className = "legend-item";
    row.innerHTML = `
      <input type="checkbox" checked data-type="${type}" style="margin-right:4px;">
      <span class="legend-swatch" style="background:${s.color}"></span>
      <span>${s.label}</span>
      <span class="count">${counts && counts[type] !== undefined ? counts[type] : ""}</span>
    `;
    row.querySelector("input").addEventListener("change", (e) => {
      row.classList.toggle("disabled", !e.target.checked);
      if (onToggle) onToggle(type, e.target.checked);
    });
    el.appendChild(row);
  });
}
