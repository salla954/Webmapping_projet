/* ==========================================================================
   bonus.js
   Regroupe les fonctionnalités bonus demandées dans le cahier des charges :
     - Géolocalisation de l'utilisateur
     - Fonds de carte supplémentaires
     - Clustering des infrastructures (plugin Leaflet.markercluster)
     - Statistiques interactives (Chart.js)
   Chaque fonction est indépendante : à récupérer telle quelle dans app.js.
   ========================================================================== */

/* ---------------------------------------------------------------------- *
 * 1. Fonds de carte supplémentaires
 * ---------------------------------------------------------------------- */

/** Retourne un objet {libellé: L.tileLayer} prêt à passer à L.control.layers. */
function buildBasemaps() {
  const osm = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "© OpenStreetMap",
    maxZoom: 19,
  });

  const positron = L.tileLayer("https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png", {
    attribution: "© OpenStreetMap, © CARTO",
    maxZoom: 19,
  });

  const satellite = L.tileLayer(
    "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    { attribution: "Tiles © Esri", maxZoom: 19 }
  );

  const terrain = L.tileLayer("https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png", {
    attribution: "© OpenTopoMap, © OpenStreetMap",
    maxZoom: 17,
  });

  return {
    "OpenStreetMap": osm,
    "Fond clair (Carto)": positron,
    "Satellite (Esri)": satellite,
    "Relief (OpenTopoMap)": terrain,
  };
}

/* ---------------------------------------------------------------------- *
 * 2. Géolocalisation de l'utilisateur
 * ---------------------------------------------------------------------- */

/**
 * Ajoute un bouton de géolocalisation en haut à gauche de la carte.
 * Au clic : centre la carte sur la position de l'utilisateur et affiche
 * un marqueur + un cercle de précision.
 */
function addGeolocationControl(map) {
  let userMarker = null;
  let userAccuracy = null;

  const LocateControl = L.Control.extend({
    options: { position: "topleft" },
    onAdd: function () {
      const div = L.DomUtil.create("div", "leaflet-bar locate-control");
      div.innerHTML = '<i class="fa-solid fa-location-crosshairs"></i>';
      div.title = "Me géolocaliser";
      L.DomEvent.disableClickPropagation(div);
      L.DomEvent.on(div, "click", () => locate());
      return div;
    },
  });
  map.addControl(new LocateControl());

  function locate() {
    if (!navigator.geolocation) {
      alert("La géolocalisation n'est pas supportée par ce navigateur.");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude, accuracy } = pos.coords;
        if (userMarker) map.removeLayer(userMarker);
        if (userAccuracy) map.removeLayer(userAccuracy);

        userMarker = L.marker([latitude, longitude], {
          icon: L.divIcon({ className: "", html: '<div class="user-location-dot"></div>', iconSize: [16, 16] }),
        }).addTo(map).bindPopup("Vous êtes ici").openPopup();

        userAccuracy = L.circle([latitude, longitude], { radius: accuracy, color: "#2E86AB", weight: 1, fillOpacity: 0.1 }).addTo(map);

        map.flyTo([latitude, longitude], 13);
      },
      () => alert("Impossible de récupérer votre position (autorisation refusée ou indisponible)."),
      { enableHighAccuracy: true }
    );
  }
}

/* ---------------------------------------------------------------------- *
 * 3. Clustering des infrastructures
 * ---------------------------------------------------------------------- */

/**
 * Construit un groupe de clusters (Leaflet.markercluster) pour un type
 * d'infrastructure donné à partir d'un FeatureCollection GeoJSON.
 * Nécessite le plugin leaflet.markercluster chargé dans index.html.
 */
function buildClusterLayer(type, geojson) {
  const cluster = L.markerClusterGroup({
    maxClusterRadius: 50,
    spiderfyOnMaxZoom: true,
  });

  const layer = L.geoJSON(geojson, {
    pointToLayer: (feature, latlng) => L.marker(latlng, { icon: getInfraIcon(type) }),
    onEachFeature: bindInfraPopup,
  });

  cluster.addLayer(layer);
  return cluster;
}

/* ---------------------------------------------------------------------- *
 * 4. Statistiques interactives
 * ---------------------------------------------------------------------- */

let statsChartInstance = null;

/**
 * Affiche/actualise un histogramme (Chart.js) du nombre d'infrastructures
 * par type, à partir d'un objet { type: count }.
 */
function renderStatsChart(canvasId, counts) {
  const labels = Object.keys(counts).map(getInfraLabel);
  const values = Object.values(counts);
  const colors = Object.keys(counts).map(getInfraColor);

  const ctx = document.getElementById(canvasId).getContext("2d");
  if (statsChartInstance) statsChartInstance.destroy();

  statsChartInstance = new Chart(ctx, {
    type: "bar",
    data: { labels, datasets: [{ data: values, backgroundColor: colors, borderRadius: 2 }] },
    options: {
      indexAxis: "y",
      plugins: { legend: { display: false } },
      scales: { x: { ticks: { precision: 0 } } },
    },
  });
}
