/* ==========================================================================
   app.js
   Glue de démonstration : initialise la carte Leaflet, charge les couches
   d'infrastructures depuis l'API SITS, et relie symbology.js / popups.js /
   bonus.js. Le formulaire de recherche multicritère (bonus) est ici aussi.

   ⚠️ Ceci est un app.js de DÉMO pour valider ta partie isolément. Dans le
   projet final, ne garde de ce fichier que ce qui concerne ta partie et
   fusionne-le avec le app.js du reste de l'équipe (init map, couches
   régions/départements, formulaires région/département "officiels", etc.).
   ========================================================================== */

const API_BASE_URL = "http://localhost:8000"; // à adapter si l'API tourne ailleurs
const INFRA_TYPES = ["centre_sante", "forage", "hotelerie", "loisirs", "lycee", "marche", "parking"];

const map = L.map("map", { center: [14.4974, -14.4524], zoom: 7 }); // centré Sénégal

// --- Fonds de carte (bonus) ---
const basemaps = buildBasemaps();
basemaps["OpenStreetMap"].addTo(map);

// --- Géolocalisation (bonus) ---
addGeolocationControl(map);

// --- Couches d'infrastructures : un cluster par type ---
const clusterLayers = {};   // { type: L.markerClusterGroup }
const rawFeatures = {};     // { type: [features] } pour les stats

async function loadInfraLayer(type) {
  const res = await fetch(`${API_BASE_URL}/api/infrastructures?type=${type}`);
  const geojson = await res.json();
  rawFeatures[type] = geojson.features;

  const cluster = buildClusterLayer(type, geojson);
  clusterLayers[type] = cluster;
  cluster.addTo(map);
}

async function initInfraLayers() {
  await Promise.all(INFRA_TYPES.map(loadInfraLayer));

  const overlays = {};
  INFRA_TYPES.forEach((t) => (overlays[getInfraLabel(t)] = clusterLayers[t]));
  L.control.layers(basemaps, overlays, { collapsed: false }).addTo(map);

  const counts = {};
  INFRA_TYPES.forEach((t) => (counts[t] = rawFeatures[t].length));
  buildLegend("legend", counts, (type, checked) => {
    if (checked) clusterLayers[type].addTo(map);
    else map.removeLayer(clusterLayers[type]);
    updateStats();
  });

  updateStats();
}

/* ---------------------------------------------------------------------- *
 * Statistiques interactives (bonus) : recalculées selon les couches actives
 * ---------------------------------------------------------------------- */

function updateStats() {
  const counts = {};
  let total = 0;
  INFRA_TYPES.forEach((t) => {
    const active = map.hasLayer(clusterLayers[t]);
    counts[t] = active ? rawFeatures[t].length : 0;
    total += counts[t];
  });
  document.getElementById("statsTotal").textContent = total.toLocaleString("fr-FR");
  renderStatsChart("statsChart", counts);
}

/* ---------------------------------------------------------------------- *
 * Recherche multicritère (bonus) : région / département / type / mot-clé
 * ---------------------------------------------------------------------- */

async function populateRegions() {
  const res = await fetch(`${API_BASE_URL}/api/regions`);
  const regions = await res.json();
  const select = document.getElementById("filterRegion");
  regions.forEach((r) => {
    const opt = document.createElement("option");
    opt.value = r.code;
    opt.textContent = r.nom;
    select.appendChild(opt);
  });
}

async function populateDepartements(regionCode) {
  const select = document.getElementById("filterDepartement");
  select.innerHTML = '<option value="">Tous</option>';
  const url = regionCode
    ? `${API_BASE_URL}/api/departements?region=${regionCode}`
    : `${API_BASE_URL}/api/departements`;
  const res = await fetch(url);
  const deps = await res.json();
  deps.forEach((d) => {
    const opt = document.createElement("option");
    opt.value = d.code;
    opt.textContent = d.nom;
    select.appendChild(opt);
  });
}

let searchResultLayer = null;

async function runMultiCriteriaSearch() {
  const type = document.getElementById("filterType").value;
  const region = document.getElementById("filterRegion").value;
  const departement = document.getElementById("filterDepartement").value;
  const q = document.getElementById("filterQ").value.trim();

  const params = new URLSearchParams();
  if (type) params.set("type", type);
  if (region) params.set("region", region);
  if (departement) params.set("departement", departement);
  if (q) params.set("q", q);

  const res = await fetch(`${API_BASE_URL}/api/infrastructures?${params.toString()}`);
  const geojson = await res.json();

  if (searchResultLayer) map.removeLayer(searchResultLayer);
  searchResultLayer = L.geoJSON(geojson, {
    pointToLayer: (feature, latlng) => L.marker(latlng, { icon: getInfraIcon(feature.properties.type) }),
    onEachFeature: bindInfraPopup,
  }).addTo(map);

  if (geojson.features.length) {
    map.fitBounds(searchResultLayer.getBounds(), { maxZoom: 14, padding: [30, 30] });
  }
  document.getElementById("searchResultCount").textContent =
    `${geojson.features.length} résultat(s)`;
}

function resetSearch() {
  document.getElementById("filterType").value = "";
  document.getElementById("filterRegion").value = "";
  populateDepartements(null);
  document.getElementById("filterQ").value = "";
  document.getElementById("searchResultCount").textContent = "";
  if (searchResultLayer) { map.removeLayer(searchResultLayer); searchResultLayer = null; }
}

/* ---------------------------------------------------------------------- *
 * Init
 * ---------------------------------------------------------------------- */

function populateTypeSelect() {
  const select = document.getElementById("filterType");
  INFRA_TYPES.forEach((t) => {
    const opt = document.createElement("option");
    opt.value = t;
    opt.textContent = getInfraLabel(t);
    select.appendChild(opt);
  });
}
populateTypeSelect();

document.getElementById("filterRegion").addEventListener("change", (e) => populateDepartements(e.target.value || null));
document.getElementById("searchForm").addEventListener("submit", (e) => { e.preventDefault(); runMultiCriteriaSearch(); });
document.getElementById("resetSearch").addEventListener("click", resetSearch);

populateRegions();
populateDepartements(null);
initInfraLayers();
