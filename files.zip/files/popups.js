/* ==========================================================================
   popups.js
   Partie "Popups" : construit le contenu descriptif affiché au clic sur une
   infrastructure (nom, code administratif, informations, statistiques),
   conformément au cahier des charges.

   Dépend de : symbology.js (getInfraColor/getInfraLabel) et de l'URL de
   l'API (API_BASE_URL, définie dans app.js / config.js).
   ========================================================================== */

/**
 * Construit le HTML d'une popup pour une feature GeoJSON d'infrastructure.
 * Le bloc statistiques est ajouté vide avec un id unique, puis rempli
 * après coup par attachPopupStats() une fois la popup ouverte (AJAX).
 */
function buildPopupContent(feature) {
  const p = feature.properties;
  const region = p.region || {};
  const dep = p.departement || {};
  const commune = p.commune || {};
  const color = getInfraColor(p.type);
  const statsId = `popup-stats-${p.id}`;

  return `
    <div class="popup-infra">
      <h3>${p.nom || "Sans nom"}</h3>
      <span class="popup-badge" style="background:${color}">${getInfraLabel(p.type)}</span>
      <table>
        <tr><td>Code région</td><td>${region.code ?? "-"}</td></tr>
        <tr><td>Région</td><td>${region.nom ?? "-"}</td></tr>
        <tr><td>Département</td><td>${dep.nom ?? "-"} (${dep.code ?? "-"})</td></tr>
        <tr><td>Commune</td><td>${commune.nom ?? "-"}</td></tr>
        <tr><td>Quartier / Village</td><td>${p.quartier_village ?? "-"}</td></tr>
        <tr><td>Milieu</td><td>${p.milieu ?? "-"}</td></tr>
      </table>
      <div class="popup-stats" id="${statsId}">Chargement des statistiques…</div>
    </div>
  `;
}

/**
 * Une fois la popup ouverte, va chercher en AJAX le nombre d'infrastructures
 * du même type dans le même département, pour donner un chiffre de contexte
 * ("12 autres marchés dans ce département").
 */
async function attachPopupStats(feature) {
  const p = feature.properties;
  const statsEl = document.getElementById(`popup-stats-${p.id}`);
  if (!statsEl || !p.departement) return;

  try {
    const url = `${API_BASE_URL}/api/infrastructures?type=${encodeURIComponent(p.type)}&departement=${p.departement.code}`;
    const res = await fetch(url);
    const data = await res.json();
    const total = data.features.length;
    const autres = Math.max(total - 1, 0);
    statsEl.innerHTML = `<strong>${autres}</strong> autre(s) ${getInfraLabel(p.type).toLowerCase()} dans ${p.departement.nom}`;
  } catch (err) {
    statsEl.textContent = "Statistiques indisponibles.";
  }
}

/**
 * Attache la popup (contenu + stats dynamiques) à une couche Leaflet,
 * à utiliser dans l'option `onEachFeature` de L.geoJSON.
 */
function bindInfraPopup(feature, layer) {
  layer.bindPopup(buildPopupContent(feature));
  layer.on("popupopen", () => attachPopupStats(feature));
}
