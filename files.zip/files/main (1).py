"""
API REST - Système d'Information Territorial du Sénégal (SITS)
Projet Webmapping L3 Géomatique

Sert les données d'infrastructures (points GeoJSON) et expose des endpoints
pour les régions, départements et infrastructures filtrées, consommables
en AJAX (Fetch API) depuis le frontend Leaflet.
"""

import glob
import json
import os
from typing import Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")

app = FastAPI(
    title="SITS - API Système d'Information Territorial du Sénégal",
    description="API REST fournissant les données territoriales et "
    "d'infrastructures du Sénégal pour l'application Webmapping.",
    version="1.0.0",
)

# CORS ouvert : nécessaire pour que le frontend (servi séparément, ex.
# Live Server sur un autre port) puisse consommer l'API en AJAX.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# Chargement des données en mémoire au démarrage
# ---------------------------------------------------------------------------

# infrastructures[type] = FeatureCollection (dict) complet
infrastructures: dict[str, dict] = {}
# toutes les features à plat, avec le type ajouté, pour faciliter les filtres croisés
all_features: list[dict] = []


def load_data() -> None:
    infrastructures.clear()
    all_features.clear()
    for filepath in sorted(glob.glob(os.path.join(DATA_DIR, "*.geojson"))):
        type_key = os.path.splitext(os.path.basename(filepath))[0]
        with open(filepath, encoding="utf-8") as f:
            geojson = json.load(f)
        infrastructures[type_key] = geojson
        for feat in geojson.get("features", []):
            all_features.append(feat)


load_data()


# ---------------------------------------------------------------------------
# Fonctions utilitaires
# ---------------------------------------------------------------------------

def feature_matches(
    feat: dict,
    type_: Optional[str],
    region_code: Optional[int],
    departement_code: Optional[int],
    milieu: Optional[str],
    q: Optional[str],
) -> bool:
    props = feat["properties"]

    if type_ and props.get("type") != type_:
        return False

    if region_code is not None:
        region = props.get("region") or {}
        if region.get("code") != region_code:
            return False

    if departement_code is not None:
        dep = props.get("departement") or {}
        if dep.get("code") != departement_code:
            return False

    if milieu and (props.get("milieu") or "").upper() != milieu.upper():
        return False

    if q:
        nom = (props.get("nom") or "").lower()
        if q.lower() not in nom:
            return False

    return True


def compute_centroid(features: list[dict]) -> Optional[list[float]]:
    """Centroïde simple (moyenne des coordonnées) d'une liste de points GeoJSON."""
    coords = [
        f["geometry"]["coordinates"]
        for f in features
        if f.get("geometry", {}).get("type") == "Point"
    ]
    if not coords:
        return None
    lon = sum(c[0] for c in coords) / len(coords)
    lat = sum(c[1] for c in coords) / len(coords)
    return [lon, lat]


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.get("/")
def root():
    return {
        "message": "API SITS - Système d'Information Territorial du Sénégal",
        "endpoints": [
            "/api/types",
            "/api/regions",
            "/api/departements",
            "/api/infrastructures",
            "/api/infrastructures/{id}",
        ],
    }


@app.get("/api/types")
def get_types():
    """Liste des types d'infrastructures disponibles, avec libellé et nombre d'entités."""
    result = []
    for type_key, geojson in infrastructures.items():
        feats = geojson.get("features", [])
        label = feats[0]["properties"]["type_label"] if feats else type_key
        result.append({"type": type_key, "type_label": label, "count": len(feats)})
    return result


@app.get("/api/regions")
def get_regions():
    """Liste des régions (déduites des données), avec centroïde et nombre total d'infrastructures."""
    regions: dict[int, dict] = {}
    for feat in all_features:
        region = feat["properties"].get("region")
        if not region or region.get("code") is None:
            continue
        code = region["code"]
        if code not in regions:
            regions[code] = {"code": code, "nom": region["nom"], "features": []}
        regions[code]["features"].append(feat)

    result = []
    for code, r in sorted(regions.items()):
        result.append(
            {
                "code": r["code"],
                "nom": r["nom"],
                "nb_infrastructures": len(r["features"]),
                "centroid": compute_centroid(r["features"]),
            }
        )
    return result


@app.get("/api/departements")
def get_departements(region: Optional[int] = Query(None, description="Code région pour filtrer")):
    """Liste des départements (déduits des données), avec centroïde. Filtrable par région."""
    departements: dict[int, dict] = {}
    for feat in all_features:
        dep = feat["properties"].get("departement")
        reg = feat["properties"].get("region")
        if not dep or dep.get("code") is None:
            continue
        if region is not None and (not reg or reg.get("code") != region):
            continue
        code = dep["code"]
        if code not in departements:
            departements[code] = {
                "code": dep["code"],
                "nom": dep["nom"],
                "region_code": reg["code"] if reg else None,
                "region_nom": reg["nom"] if reg else None,
                "features": [],
            }
        departements[code]["features"].append(feat)

    result = []
    for code, d in sorted(departements.items()):
        result.append(
            {
                "code": d["code"],
                "nom": d["nom"],
                "region_code": d["region_code"],
                "region_nom": d["region_nom"],
                "nb_infrastructures": len(d["features"]),
                "centroid": compute_centroid(d["features"]),
            }
        )
    return result


@app.get("/api/infrastructures")
def get_infrastructures(
    type: Optional[str] = Query(None, description="Type d'infrastructure, ex: forage, marche, lycee"),
    region: Optional[int] = Query(None, description="Code région"),
    departement: Optional[int] = Query(None, description="Code département"),
    milieu: Optional[str] = Query(None, description="URBAIN ou RURAL"),
    q: Optional[str] = Query(None, description="Recherche texte sur le nom"),
):
    """
    Retourne les infrastructures filtrées au format GeoJSON FeatureCollection,
    prêt à être injecté directement dans une couche Leaflet (L.geoJSON).
    """
    if type and type not in infrastructures:
        raise HTTPException(status_code=404, detail=f"Type inconnu: {type}")

    source = all_features if not type else infrastructures[type]["features"]
    filtered = [
        f for f in source if feature_matches(f, type, region, departement, milieu, q)
    ]
    return {"type": "FeatureCollection", "features": filtered}


@app.get("/api/infrastructures/{feature_id}")
def get_infrastructure_by_id(feature_id: str):
    """Détail d'une infrastructure par son id (ex: forage-42)."""
    for feat in all_features:
        if feat["properties"].get("id") == feature_id:
            return feat
    raise HTTPException(status_code=404, detail="Infrastructure introuvable")
